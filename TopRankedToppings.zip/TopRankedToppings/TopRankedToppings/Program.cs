﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace JSONDemo
{
    class PizzaData
    {
        private readonly String[] pizza;

        public PizzaData(String[] pz)
        {
            this.pizza = pz;
        }

        public String[] PizzaMethod()
        {
            return pizza;
        }
    }

    class Program
    {
        public static void Main(string[] args)
        {
            // These 4 lines get the JSON file from the specified URL
            string URL = "http://files.olo.com/pizzas.json";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
            request.ContentType = "application/json; charset=utf-8";
            HttpWebResponse response = request.GetResponse() as HttpWebResponse;

            // convert the response document to a stream type object for processing
            using (Stream responseStream = response.GetResponseStream())
            {
                StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
                // convert the stream to a simple String object
                String workLine;
                int pizzaTotal = 0;
                int typeMax = 0;
                int typeCount = 0;
                int toppingTotal = 0;
                List<String> toppingTable = new List<String>();
                List<String> toppingsList = new List<String>();
                List<String> toppingCompare = new List<String>();
                toppingTable.Clear();
                toppingsList.Clear();

                Console.WriteLine("Processing Topping Types..." + "\n" + "\n");

                while (reader.EndOfStream != true)
                {
                    workLine = reader.ReadLine();
                    int headerCheck = workLine.IndexOf('[');
                    int symType1 = workLine.IndexOf('{');
                    int symType2 = workLine.IndexOf(']');
                    int symType3 = workLine.IndexOf('}');
                    int symType4 = workLine.IndexOf(',');

                    if (headerCheck == -1 && symType1 == -1 && symType2 == -1 && symType3 == -1)
                    {
                        toppingTable.Add(workLine);
                        toppingsList.Add(toppingTable[pizzaTotal]);
                        pizzaTotal++;
                        typeCount++;

                        if (symType4 == -1)
                        {
                            if (typeCount > typeMax)
                            { typeMax = typeCount; }
                        }
                        String[] groupedToppings = new String[typeCount];
                        String[] toppingsCompare = new String[pizzaTotal];

                        if (symType4 == -1)
                        {
                            int toppingsMax = typeCount;
                            int pizzaTotal1 = pizzaTotal - toppingsMax;
                            typeCount = 0;

                            do
                            {
                                groupedToppings[typeCount++] = toppingsList[pizzaTotal1++];
                            } while (typeCount < toppingsMax);

                            Array.Sort(groupedToppings);
                            toppingsCompare[toppingTotal] = string.Concat(groupedToppings);
                            toppingCompare.Add(toppingsCompare[toppingTotal]);
                            toppingTotal++;

                            for (int i = 0; i < groupedToppings.Length; i++)
                            {
                                groupedToppings[i] = null;
                            }
                            typeCount = 0;
                        }
                    }
                }
                reader.Close();



                //Sorting and counting toppings
                typeCount = 0;
                int typeCount1 = 0;
                List<int> totals = new List<int>();
                List<String> finalList = new List<String>();
                bool contains = false;
                int workTotals = 0;
                int toppingTotal1 = toppingTotal;
                string work;
                List<int> groupTotal = new List<int>();

                do
                {
                    work = toppingCompare[typeCount1];
                    typeCount = 0;
                    workTotals = 0;
                    contains = false;
                    contains = finalList.Contains(work);

                    do
                    {
                        if (toppingCompare[typeCount] == work)
                        {
                            workTotals++;
                        }

                        typeCount++;

                    } while (typeCount < toppingTotal);

                    if (contains != true)
                    {
                        finalList.Add(work);
                        groupTotal.Add(workTotals);
                    }
                    typeCount1++;

                } while (typeCount1 < toppingTotal1);

                int totalTop = finalList.Count;



                //Copying array for comparison

                int counting = 0;
                List<String> groupToppings = new List<string>();
                List<String> toppingString = new List<string>();
                List<int> toppingTotFinal = new List<int>();
                int gpTotal = groupTotal.Count;
                int[] countArray = new int[gpTotal];
                do
                {
                    countArray[counting] = groupTotal[counting++];
                } while (counting < gpTotal);

                Array.Sort(countArray);
                Array.Reverse(countArray);

                int countIndex = 0;
                int counting2 = 0;

                do
                {
                    countIndex = 0;
                    do
                    {
                        if (groupTotal[countIndex] == countArray[counting2])
                        {
                            groupToppings.Add(groupTotal[countIndex] + finalList[countIndex]);
                            toppingString.Add(finalList[countIndex]);
                            toppingTotFinal.Add(groupTotal[countIndex]);
                        }

                        countIndex++;

                    } while (countIndex < totalTop);

                    counting2++;

                } while (counting2 < 20);





                //Output the totals with their ranking
                countIndex = 0;
                int totalTop1 = groupToppings.Count;
                int rank = 1;
                String labelBorder = "--------------------------------------   -------";
                int lbCount = labelBorder.Length;
                int ttCount = toppingString[countIndex].Length;
                int rptTot = lbCount - ttCount;
                String rptTypeSub;
                List<String> rptType = new List<String>();
                string rptSpace = " ";

                Console.WriteLine("RANK" + " " + "                 TOPPING TYPE                " + "COUNT");
                Console.WriteLine("----" + "    " + labelBorder);
                do
                {
                    rptTypeSub = toppingString[countIndex];
                    do
                    {
                        rptTypeSub = rptTypeSub + rptSpace;
                        ttCount = rptTypeSub.Length;
                        rptTot = lbCount - ttCount;
                    } while (rptTot > 0);
                    rptType.Add(rptTypeSub);
                    Console.WriteLine(" " + rank + " " + rptType[countIndex] + " " + toppingTotFinal[countIndex]);
                    countIndex++;
                    rank++;
                } while (countIndex < 20);

                Console.ReadKey();
            }
        }
    }
}





